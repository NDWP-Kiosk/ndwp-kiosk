const WAKE_SYS_API = "https://northdevonwakepark.wakesys.com/api/events.php";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Cache-Control": "no-store"
};

export default {
  async fetch(request) {
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders });
    }

    if (request.method !== "GET") {
      return new Response(JSON.stringify({ error: "GET only" }), {
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    try {
      const incoming = new URL(request.url);
      const today = new Date();
      const tomorrow = new Date(today.getTime() + 86400000);

      const start = incoming.searchParams.get("start") ||
        today.toISOString().slice(0, 10);
      const stop = incoming.searchParams.get("stop") ||
        tomorrow.toISOString().slice(0, 10);

      // WakeSys returns JSONP, so ask it for a known callback name.
      const apiUrl = new URL(WAKE_SYS_API);
      apiUrl.searchParams.set("callback", "displayEventList");
      apiUrl.searchParams.set("start", start);
      apiUrl.searchParams.set("stop", stop);

      const upstream = await fetch(apiUrl.toString(), {
        method: "GET",
        headers: {
          "Accept": "application/javascript,text/javascript,*/*"
        },
        cf: {
          cacheTtl: 30,
          cacheEverything: true
        }
      });

      if (!upstream.ok) {
        return new Response(JSON.stringify({
          error: "WakeSys returned HTTP " + upstream.status
        }), {
          status: 502,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      }

      const body = await upstream.text();

      // Expected format:
      // displayEventList([...events...])
      const firstParen = body.indexOf("(");
      const lastParen = body.lastIndexOf(")");

      if (firstParen === -1 || lastParen <= firstParen) {
        return new Response(JSON.stringify({
          error: "WakeSys response was not valid JSONP",
          preview: body.slice(0, 300)
        }), {
          status: 502,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      }

      const jsonText = body.slice(firstParen + 1, lastParen);
      const data = JSON.parse(jsonText);

      return new Response(JSON.stringify({
        ok: true,
        source: "WakeSys",
        fetchedAt: new Date().toISOString(),
        start,
        stop,
        eventCount: Array.isArray(data) ? data.length : 0,
        events: Array.isArray(data) ? data : []
      }), {
        status: 200,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json; charset=utf-8"
        }
      });

    } catch (error) {
      return new Response(JSON.stringify({
        ok: false,
        error: String(error && error.message ? error.message : error)
      }), {
        status: 502,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json; charset=utf-8"
        }
      });
    }
  }
};
